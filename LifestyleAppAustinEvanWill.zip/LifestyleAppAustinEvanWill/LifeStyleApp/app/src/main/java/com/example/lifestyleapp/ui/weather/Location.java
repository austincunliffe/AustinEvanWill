package com.example.lifestyleapp.ui.weather;

public class Location {
    String city;
    String country;

    public Location(String city, String country) {
        this.city = city;
        this.country = country;
    }
}
