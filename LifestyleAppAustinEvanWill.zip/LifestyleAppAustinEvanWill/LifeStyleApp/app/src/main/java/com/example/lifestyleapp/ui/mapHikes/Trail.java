package com.example.lifestyleapp.ui.mapHikes;

public class Trail {
    String name;
    float lon;
    float lat;

    Trail(String name, float lon, float lat){
        this.name = name;
        this.lat =lat;
        this.lon = lon;
    }
}
