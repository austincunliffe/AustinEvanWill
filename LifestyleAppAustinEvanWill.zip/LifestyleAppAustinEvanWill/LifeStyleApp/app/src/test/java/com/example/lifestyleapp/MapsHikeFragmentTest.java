package com.example.lifestyleapp;

import com.example.lifestyleapp.ui.mapHikes.MapsHikeFragment;

import org.junit.Test;

import static org.junit.Assert.*;

public class MapsHikeFragmentTest {

    @Test
    public void getNearbyHikesTest1() {
    }
}